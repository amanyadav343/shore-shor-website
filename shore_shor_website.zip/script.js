function launchSite() {
    alert("Shore शोर is launching... Get ready for an amazing experience!");
}